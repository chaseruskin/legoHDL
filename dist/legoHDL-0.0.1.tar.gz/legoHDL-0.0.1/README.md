# _lego_**HDL**

### The simple, lightweight, flexible package manager for HDL design modules.
<br></br>
How to get up and running in no time.
<br></br>

1. Download and open the _lego_**HDL** directory
2. Tweak the settings.yml (it can be changed later!)
3. Run ```python3 ./setup.py```
4. Run ```legoHDL help``` in the terminal
5. The world awaits!