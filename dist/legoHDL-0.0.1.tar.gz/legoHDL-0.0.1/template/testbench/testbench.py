#python module to generate input test vector file and expected results file
#have a "testkit" python helper module somewhere to have ready-available code that can
# aid in tuning random inputs & writing scoreboard